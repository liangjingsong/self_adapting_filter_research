% ����������һ��ԭ�ȵ�lms
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
iteration=3000;
N=300;

time=[1:iteration+N].';

d=1*cos(2*pi/N*11*time+1/1)...
    +0.4*cos(2*pi/N*21.7*time+1/2)...
    +0.7*cos(2*pi/N*51.2*time+1/4)...
    +1.0*cos(2*pi/N*91.9*time+1/8);

x=0.2*cos(2*pi/N*11*time+1/8)...
    +0.5*cos(2*pi/N*21.7*time+1/4)...
    +0.2*cos(2*pi/N*51.2*time+1/2)...
    +0.3*cos(2*pi/N*91.9*time+1/1);

filter_time=[1:N].';

w=0*cos(2*pi/N*1*filter_time+0)...
    +0*cos(2*pi/N*2*filter_time+0)...
    +0*cos(2*pi/N*3*filter_time+0)...
    +0*cos(2*pi/N*4*filter_time+0)...
    +0*cos(2*pi/N*5*filter_time+0);

mui=0.01;

y=zeros(1,iteration);
e=zeros(1,iteration);

for i=[1:iteration]
   y(i)=x(i:i+N-1).'*w;
   e(i)=d(i+N)-y(i);
   w=w+mui*e(i)*x(i:i+N-1);
end

cftool_time=[1:iteration]/1000;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% ����һ��֮ǰ��
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
e_old=e;
x_old=x;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% ����һ���ź���˵
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
fft_N=200;
spec=abs(fft(x(1:fft_N)));
spec=reshape(spec,1,fft_N);

normalize_spec=spec/max(spec);
r=0.07;
max_pool_length=1;
new_normalize_spec=normalize_spec;
for i=(1+max_pool_length):(fft_N-max_pool_length)
    new_normalize_spec(i)=max(normalize_spec(i-max_pool_length:i+max_pool_length));
end
f_a=(new_normalize_spec>r).*(1./new_normalize_spec)+(new_normalize_spec<=r);
pre_fir=fir2(fft_N,[0:1/((fft_N/2)-1):1],f_a(1:fft_N/2));

% get pre_fir

x=conv(x,pre_fir,'same');
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % ��ʼ�Ա�
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
w=0*cos(2*pi/N*1*filter_time+0)...
    +0*cos(2*pi/N*2*filter_time+0)...
    +0*cos(2*pi/N*3*filter_time+0)...
    +0*cos(2*pi/N*4*filter_time+0)...
    +0*cos(2*pi/N*5*filter_time+0);

for i=[1:iteration]
   y(i)=x(i:i+N-1).'*w;
   e(i)=d(i+N)-y(i);
   w=w+mui*e(i)*x(i:i+N-1);
end

figure
subplot(4,1,1);
plot(e_old(1:iteration));
axis([0 2500 -2 2]);
subplot(4,1,2);
plot(e(1:iteration-500));
axis([0 2500 -2 2]);

% ��һ����ʾ
subplot(4,1,3)
emmm=abs(fft(x_old(1000:1300))); 

plot([0:1/149:1],emmm(1:150)/75);
subplot(4,1,4)
emmm=abs(fft(x(1000:1300))); 
plot([0:1/149:1],emmm(1:150)/75);
