clear;
close all;
clc;

ecg=importdata('work_5_data.mat');          %�����ĵ�����
d=ecg(2,:);
x=ecg(1,:);

d=reshape(d,30721,1);
x=reshape(x,30721,1);

fir_lowpass=fir2(50,[0,0.3,0.3,1],[1,1,0,0]);
d=conv(d,fir_lowpass,'same');
x=conv(x,fir_lowpass,'same');

iteration=length(d)-600;
N=150;
delay=-60;

filter_time=[1:N].';

w=0*cos(2*pi/N*1*filter_time+0)...
    +0*cos(2*pi/N*2*filter_time+0)...
    +0*cos(2*pi/N*3*filter_time+0)...
    +0*cos(2*pi/N*4*filter_time+0)...
    +0*cos(2*pi/N*5*filter_time+0);

mui=0.003;

y=zeros(1,iteration);
e=zeros(1,iteration);

for i=[1:iteration]
   y(i)=x(i:i+N-1).'*w;
   e(i)=d(delay+i+N)-y(i);
   w=w+mui*e(i)*x(i:i+N-1);
end

d_old=d;
e_old=e;
x_old=x;
y_old=y;

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% ����һ���ź���˵
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
fft_N=200;
spec=abs(fft(x(1:fft_N)));
spec=reshape(spec,1,fft_N);

normalize_spec=spec/max(spec);
r=0.05;
max_pool_length=1;
new_normalize_spec=normalize_spec;
for i=(1+max_pool_length):(fft_N-max_pool_length)
    new_normalize_spec(i)=max(normalize_spec(i-max_pool_length:i+max_pool_length));
end
f_a=(new_normalize_spec>r).*(1./new_normalize_spec)+(new_normalize_spec<=r);
pre_fir=fir2(fft_N,[0:1/((fft_N/2)-1):1],f_a(1:fft_N/2));

% get pre_fir

x=conv(x,pre_fir,'same');
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

N=150;
delay=-60;

w=0*cos(2*pi/N*1*filter_time+0)...
    +0*cos(2*pi/N*2*filter_time+0)...
    +0*cos(2*pi/N*3*filter_time+0)...
    +0*cos(2*pi/N*4*filter_time+0)...
    +0*cos(2*pi/N*5*filter_time+0);

y=zeros(1,iteration);
e=zeros(1,iteration);

for i=[1:iteration]
   y(i)=x(i:i+N-1).'*w;
   e(i)=d(delay+i+N)-y(i);
   w=w+mui*e(i)*x(i:i+N-1);
end

cftool_time=[1:iteration]/1000;

figure;
subplot(4,1,1);plot(e_old);axis([0,15000,-0.3,+0.3]);
subplot(4,1,2);plot(e);axis([0,15000,-0.3,+0.3]);


time=100;
datal=500;

emmm=abs(fft(x_old(time:time+datal)));
subplot(4,1,3);plot([0:1/250:1],emmm(1:251)/15);
axis([0,1,0,1]);

emmm=abs(fft(x(time:time+datal)));
subplot(4,1,4);plot([0:1/250:1],emmm(1:251)/15);
axis([0,1,0,1]);
