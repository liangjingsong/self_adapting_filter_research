iteration=3000;
N=300;

time=[1:iteration+N].';


% +a1*exp(-b1*x)*cos(2*pi/300*11*x*1000+p1)
% +a2*exp(-b2*x)*cos(2*pi/300*21*x*1000+p2)
% +a3*exp(-b3*x)*cos(2*pi/300*31*x*1000+p3)
% +a4*exp(-b4*x)*cos(2*pi/300*41*x*1000+p4)

d=1*cos(2*pi/N*11*time+1/1)...
    +0.4*cos(2*pi/N*21*time+1/2)...
    +0.7*cos(2*pi/N*31*time+1/4)...
    +1.0*cos(2*pi/N*41*time+1/8);

x=0.4*cos(2*pi/N*11*time+1/8)...
    +0*cos(2*pi/N*21*time+1/4)...
    +0.7*cos(2*pi/N*31*time+1/2)...
    +0.3*cos(2*pi/N*41*time+1/1);


filter_time=[1:N].';

w=0*cos(2*pi/N*1*filter_time+0)...
    +0*cos(2*pi/N*2*filter_time+0)...
    +0*cos(2*pi/N*3*filter_time+0)...
    +0*cos(2*pi/N*4*filter_time+0)...
    +0*cos(2*pi/N*5*filter_time+0);

mui=2e-4;

y=zeros(1,iteration);
e=zeros(1,iteration);

for i=[1:iteration]
   y(i)=x(i:i+N-1).'*w;
   e(i)=d(i+N)-y(i);
   w=w+mui*e(i)*x(i:i+N-1);
end

cftool_time=[1:iteration]/1000;