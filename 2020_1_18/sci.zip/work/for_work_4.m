figure;
subplot(4,1,1);plot(e1);axis([0,3000000,-2,2]);
subplot(4,1,2);plot(e);axis([0,3000000,-2,2]);


time=1000;
datal=1000;

emmm=abs(fft(x1(time:time+datal)));
subplot(4,1,3);plot([0:1/500:1],emmm(1:500+1)/70);
axis([0,1,0,1]);

emmm=abs(fft(x(time:time+datal)));
subplot(4,1,4);plot([0:1/500:1],emmm(1:500+1)/70);
axis([0,1,0,1]);
