% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % % % % % % % % % % % % ��ͨ��LMS % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
iteration=1500;
N=100;

time=[1:iteration+N].';

d=1*cos(2*pi/N*11*time+1/1)...
    +0.4*cos(2*pi/N*2*time+1/2)...
    +0.7*cos(2*pi/N*5*time+1/4)...
    +1.0*cos(2*pi/N*7*time+1/8);

x=0.2*cos(2*pi/N*11*time+1/8)...
    +0.5*cos(2*pi/N*2*time+1/4)...
    +0.2*cos(2*pi/N*5*time+1/2)...
    +0.3*cos(2*pi/N*7*time+1/1);

filter_time=[1:N].';

w=0*cos(2*pi/N*1*filter_time+0)...
    +0*cos(2*pi/N*2*filter_time+0)...
    +0*cos(2*pi/N*3*filter_time+0)...
    +0*cos(2*pi/N*4*filter_time+0)...
    +0*cos(2*pi/N*5*filter_time+0);

mui=0.004;

y=zeros(1,iteration);
e=zeros(1,iteration);

for i=[1:iteration]
   y(i)=x(i:i+N-1).'*w;
   e(i)=d(i+N)-y(i);
   w=w+mui*e(i)*x(i:i+N-1);
end

figure;
subplot(4,1,1);plot(e);axis([0,1000,-2,2]);

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % % % % % % % % % % % % NTVLMS% % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 

time=[1:iteration+N].';

d=1*cos(2*pi/N*11*time+1/1)...
    +0.4*cos(2*pi/N*21.7*time+1/2)...
    +0.7*cos(2*pi/N*51.2*time+1/4)...
    +1.0*cos(2*pi/N*91.9*time+1/8);

x=0.2*cos(2*pi/N*11*time+1/8)...
    +0.5*cos(2*pi/N*21.7*time+1/4)...
    +0.2*cos(2*pi/N*51.2*time+1/2)...
    +0.3*cos(2*pi/N*91.9*time+1/1);

filter_time=[1:N].';

w=0*cos(2*pi/N*1*filter_time+0)...
    +0*cos(2*pi/N*2*filter_time+0)...
    +0*cos(2*pi/N*3*filter_time+0)...
    +0*cos(2*pi/N*4*filter_time+0)...
    +0*cos(2*pi/N*5*filter_time+0);

mui_mui=0.018/(pi/2);
mui_d=0.018+0.004;
mui_f=0.06;
mui_g=0.01;


y=zeros(1,iteration);
e=zeros(1,iteration);

for i=[1:iteration]
   y(i)=x(i:i+N-1).'*w;
   e(i)=d(i+N)-y(i);
   w=w+(mui_d+mui_mui*atan(-mui_f*i+mui_g))*e(i)*x(i:i+N-1);
end

cftool_time=[1:iteration]/1000;

subplot(4,1,3);plot(e);axis([0,1000,-2,2]);


% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% ����һ���ź���˵
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
fft_N=200;
spec=abs(fft(x(1:fft_N)));
spec=reshape(spec,1,fft_N);

normalize_spec=spec/max(spec);
r=0.07;
max_pool_length=1;
new_normalize_spec=normalize_spec;
for i=(1+max_pool_length):(fft_N-max_pool_length)
    new_normalize_spec(i)=max(normalize_spec(i-max_pool_length:i+max_pool_length));
end
f_a=(new_normalize_spec>r).*(1./new_normalize_spec)+(new_normalize_spec<=r);
pre_fir=fir2(fft_N,[0:1/((fft_N/2)-1):1],f_a(1:fft_N/2));

% get pre_fir

x=conv(x,pre_fir,'same');

w=0*cos(2*pi/N*1*filter_time+0)...
    +0*cos(2*pi/N*2*filter_time+0)...
    +0*cos(2*pi/N*3*filter_time+0)...
    +0*cos(2*pi/N*4*filter_time+0)...
    +0*cos(2*pi/N*5*filter_time+0);

y=zeros(1,iteration);
e=zeros(1,iteration);

for i=[1:iteration]
   y(i)=x(i:i+N-1).'*w;
   e(i)=d(i+N)-y(i);
   w=w+(mui_d+mui_mui*atan(-mui_f*i+mui_g))*e(i)*x(i:i+N-1);
end

subplot(4,1,4);plot(e);axis([0,1000,-2,2]);

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % % % % % % % % % % % % % % ֻ���� û��NTVLMS% % % % % % %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

w=0*cos(2*pi/N*1*filter_time+0)...
    +0*cos(2*pi/N*2*filter_time+0)...
    +0*cos(2*pi/N*3*filter_time+0)...
    +0*cos(2*pi/N*4*filter_time+0)...
    +0*cos(2*pi/N*5*filter_time+0);

y=zeros(1,iteration);
e=zeros(1,iteration);

for i=[1:iteration]
   y(i)=x(i:i+N-1).'*w;
   e(i)=d(i+N)-y(i);
   w=w+mui*e(i)*x(i:i+N-1);
end

subplot(4,1,2);plot(e);
axis([0,1000,-2,2]);


figure;
plot([1:1500],mui_d+mui_mui*atan(-mui_f*[1:iteration]+mui_g),'-r',[1:1500],mui*ones(1,1500),'-b');
% plot([1:1500],mui*ones(1,1500));
axis([1,1000,0,0.02])